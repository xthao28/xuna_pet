// S11 measurement harness, isolated from xuna_life. No writes until explicit serial command.
#include <Arduino.h>
#include <Preferences.h>
#include <LittleFS.h>
#include <nvs.h>
#include <esp_partition.h>
#include <algorithm>
#include <cstring>
#include "DisplayManager.h"
#include "Crc32.h"
namespace {
xuna::DisplayManager display;
xuna::AnimationManager animation;
bool displayReady=false,mounted=false;
uint32_t samples[10000],renders[10000],gaps[10000];
size_t writes=0,renderCount=0,gapCount=0;
uint32_t previousTick=0;
uint8_t blob[1536],snapshot[16384];
uint32_t sequence=0;
void put32(uint8_t* b,uint32_t v){for(unsigned i=0;i<4;++i)b[i]=v>>(i*8);}
uint32_t get32(const uint8_t* b){uint32_t v=0;for(unsigned i=0;i<4;++i)v|=uint32_t(b[i])<<(i*8);return v;}
void make(uint8_t* b,size_t n,uint32_t seq){memset(b,0,n);put32(b,seq);put32(b+n-4,xuna::crc32(b,n-4));}
bool valid(const uint8_t* b,size_t n){return get32(b+n-4)==xuna::crc32(b,n-4);}
void tick(){
 const uint32_t now=micros();
 if(previousTick&&gapCount<10000)gaps[gapCount++]=now-previousTick;
 previousTick=now;
 if(displayReady&&animation.update(millis())){
  const uint32_t start=micros();display.render(animation.state(),animation.frame());
  if(renderCount<10000)renders[renderCount++]=micros()-start;
 }
}
void beginPhase(){writes=renderCount=gapCount=0;previousTick=micros();}
void stats(const char* label,uint32_t* values,size_t count){
 if(!count){Serial.printf("%s,n=0\n",label);return;}
 std::sort(values,values+count);
 Serial.printf("%s,n=%u,p50_us=%u,p99_us=%u,max_us=%u\n",label,unsigned(count),values[(count-1)*50/100],values[(count-1)*99/100],values[count-1]);
}
void report(const char* phase,uint32_t heapBefore){
 Serial.printf("phase=%s,heap_before=%u,heap_after=%u,heap_min=%u\n",phase,heapBefore,ESP.getFreeHeap(),ESP.getMinFreeHeap());
 stats("write",samples,writes);stats("render",renders,renderCount);stats("tick_gap",gaps,gapCount);
}
bool recoverNvs(Preferences& prefs){
 uint8_t candidate[1536];bool any=false,seen=false;uint32_t newest=0;
 for(const char* key:{"a","b"}){
  if(!prefs.isKey(key))continue;seen=true;
  const size_t size=prefs.getBytesLength(key);
  const bool ok=size==sizeof(candidate)&&prefs.getBytes(key,candidate,sizeof(candidate))==sizeof(candidate)&&valid(candidate,sizeof(candidate));
  Serial.printf("nvs_slot=%s,valid=%u\n",key,ok);
  if(ok&&(!any||int32_t(get32(candidate)-newest)>0)){newest=get32(candidate);any=true;}
 }
 sequence=any?newest:0;Serial.printf("nvs_newest=%u\n",sequence);
 if(seen&&!any){Serial.println("ERROR both NVS slots invalid; refusing new writes");return false;}return true;
}
void nvsBench(bool storm){
 Preferences prefs;if(!prefs.begin("xuna_bench",false)){Serial.println("ERROR nvs open");return;}
 if(!recoverNvs(prefs)){prefs.end();return;}nvs_stats_t storage={};nvs_get_stats(nullptr,&storage);Serial.printf("nvs_free_entries_before=%u\n",unsigned(storage.free_entries));
 beginPhase();const uint32_t heap=ESP.getFreeHeap();
 const unsigned count=storm?UINT32_MAX:1000;
 for(unsigned i=0;i<count;++i){
  if(sequence==UINT32_MAX){Serial.println("STOP sequence exhausted");break;}
  make(blob,sizeof(blob),++sequence);tick();const uint32_t start=micros();
  const size_t written=prefs.putBytes(sequence&1?"a":"b",blob,sizeof(blob));const uint32_t elapsed=micros()-start;
  if(writes<10000)samples[writes++]=elapsed;
  if(written!=sizeof(blob)){Serial.println("ERROR nvs short write");break;}
  if(storm&&(i%100==0))Serial.printf("storm_seq=%u\n",sequence);
  if(storm&&Serial.available()&&Serial.read()=='q')break;
 }
 report(storm?"nvs_storm":"nvs",heap);nvs_get_stats(nullptr,&storage);Serial.printf("nvs_free_entries_after=%u\n",unsigned(storage.free_entries));prefs.end();
}
bool mount(){
 if(mounted)return true;
 const uint32_t start=micros();mounted=LittleFS.begin(false,"/littlefs",10,"spiffs");
 Serial.printf("mount_ok=%u,mount_us=%u\n",mounted,micros()-start);
 if(!mounted){Serial.println("NOT FORMATTING: verify/backup unused partition first");return false;}
 Serial.printf("fs_total=%u,fs_used=%u\n",unsigned(LittleFS.totalBytes()),unsigned(LittleFS.usedBytes()));
 return true;
}
void fsBench(){
 if(!mount())return;
 if(!LittleFS.exists("/xuna_bench")&&!LittleFS.mkdir("/xuna_bench")){Serial.println("ERROR mkdir");return;}
 beginPhase();uint32_t heap=ESP.getFreeHeap();uint8_t record[40];
 for(unsigned i=0;i<10000;++i){
  char path[48];snprintf(path,sizeof(path),"/xuna_bench/seg%u",(i/102)%16);
  const bool rotate=i%102==0;auto file=LittleFS.open(path,rotate?FILE_WRITE:FILE_APPEND);
  if(!file){Serial.println("ERROR open segment");break;}
  make(record,sizeof(record),i+1);tick();const uint32_t start=micros();
  const size_t n=file.write(record,sizeof(record));file.flush();file.close();samples[writes++]=micros()-start;
  if(n!=sizeof(record)){Serial.println("ERROR short append");break;}
 }
 report("fs_append",heap);beginPhase();heap=ESP.getFreeHeap();
 for(unsigned i=0;i<200;++i){
  make(snapshot,sizeof(snapshot),i+1);tick();const uint32_t start=micros();
  auto file=LittleFS.open("/xuna_bench/snapshot.tmp",FILE_WRITE);
  if(!file){Serial.println("ERROR temp open");break;}
  const size_t n=file.write(snapshot,sizeof(snapshot));file.flush();file.close();
  const bool renamed=n==sizeof(snapshot)&&LittleFS.rename("/xuna_bench/snapshot.tmp","/xuna_bench/snapshot.bin");
  samples[writes++]=micros()-start;
  if(!renamed){Serial.println("ERROR rename/write");break;}
 }
 report("fs_snapshot",heap);
 auto file=LittleFS.open("/xuna_bench/snapshot.bin",FILE_READ);
 const bool ok=file&&file.size()==sizeof(snapshot);
 // Validate full snapshot with separate fixed buffer (never read a 16 KiB file into the 1.5 KiB blob).
 const bool contents=ok&&file.read(snapshot,sizeof(snapshot))==sizeof(snapshot)&&valid(snapshot,sizeof(snapshot));
 Serial.printf("snapshot_readback_crc=%u,fs_used=%u\n",contents,unsigned(LittleFS.usedBytes()));file.close();
}
void formatErased(){
 const esp_partition_t* part=esp_partition_find_first(ESP_PARTITION_TYPE_DATA,ESP_PARTITION_SUBTYPE_ANY,"spiffs");
 if(!part){Serial.println("ERROR no spiffs partition");return;}
 for(size_t offset=0;offset<part->size;offset+=sizeof(snapshot)){
  const size_t n=std::min(sizeof(snapshot),size_t(part->size-offset));
  if(esp_partition_read(part,offset,snapshot,n)!=ESP_OK){Serial.println("ERROR partition read");return;}
  for(size_t i=0;i<n;++i)if(snapshot[i]!=255){Serial.println("REFUSE FORMAT: partition contains data; do not erase");return;}
 }
 Serial.println("Entire partition erased; explicit F command formats LittleFS");
 if(!LittleFS.format())Serial.println("ERROR format");else mount();
}
bool recoverFs(){
 if(!mount())return false;
 if(!LittleFS.exists("/xuna_bench")&&!LittleFS.mkdir("/xuna_bench"))return false;
 bool any=false;uint32_t newest=0;
 for(unsigned segment=0;segment<16;++segment){
  char path[48];snprintf(path,sizeof(path),"/xuna_bench/seg%u",segment);
  auto file=LittleFS.open(path,FILE_READ);if(!file)continue;
  const size_t size=file.size();
  if(size>4096){file.close();Serial.println("ERROR oversized segment; refusing recovery");return false;}
  const size_t got=file.read(snapshot,size);file.close();if(got!=size)return false;
  size_t intact=0;uint32_t previous=0;
  while(intact+40<=size&&valid(snapshot+intact,40)){
   const uint32_t seq=get32(snapshot+intact);
   if(!seq||(intact&&seq!=previous+1))break;
   previous=seq;if(!any||int32_t(seq-newest)>0){newest=seq;any=true;}intact+=40;
  }
  if(intact!=size){
   auto repaired=LittleFS.open("/xuna_bench/recovery.tmp",FILE_WRITE);if(!repaired)return false;
   const size_t written=repaired.write(snapshot,intact);repaired.flush();repaired.close();
   if(written!=intact||!LittleFS.rename("/xuna_bench/recovery.tmp",path))return false;
   Serial.printf("torn_segment=%u,valid_bytes=%u,removed_bytes=%u\n",segment,unsigned(intact),unsigned(size-intact));
  }
 }
 sequence=any?newest:0;Serial.printf("fs_newest=%u\n",sequence);return true;
}
void fsStorm(){
 if(!recoverFs())return;beginPhase();const uint32_t heap=ESP.getFreeHeap();
 uint8_t record[40];
 while(sequence!=UINT32_MAX){
  const uint32_t next=sequence+1;char path[48];
  snprintf(path,sizeof(path),"/xuna_bench/seg%u",((next-1)/102)%16);
  auto file=LittleFS.open(path,(next-1)%102==0?FILE_WRITE:FILE_APPEND);if(!file){Serial.println("ERROR storm open");break;}
  make(record,sizeof(record),next);tick();const uint32_t start=micros();
  const size_t n=file.write(record,sizeof(record));file.flush();file.close();
  if(writes<10000)samples[writes++]=micros()-start;
  if(n!=sizeof(record)){Serial.println("ERROR storm short write");break;}sequence=next;
  if(sequence%100==0)Serial.printf("fs_storm_seq=%u\n",sequence);
  if(Serial.available()&&Serial.read()=='q')break;
 }
 report("fs_storm",heap);
}
void snapshotStorm(){
 if(!mount())return;
 if(!LittleFS.exists("/xuna_bench")&&!LittleFS.mkdir("/xuna_bench"))return;
 auto old=LittleFS.open("/xuna_bench/snapshot.bin",FILE_READ);sequence=0;
 if(old){const bool ok=old.size()==sizeof(snapshot)&&old.read(snapshot,sizeof(snapshot))==sizeof(snapshot)&&valid(snapshot,sizeof(snapshot));
  if(!ok){old.close();Serial.println("ERROR snapshot invalid; retaining artifacts");return;}sequence=get32(snapshot);old.close();}
 Serial.printf("snapshot_newest=%u,tmp_present=%u\n",sequence,LittleFS.exists("/xuna_bench/snapshot.tmp"));
 beginPhase();const uint32_t heap=ESP.getFreeHeap();
 while(sequence!=UINT32_MAX){
  make(snapshot,sizeof(snapshot),sequence+1);tick();const uint32_t start=micros();
  auto file=LittleFS.open("/xuna_bench/snapshot.tmp",FILE_WRITE);if(!file)break;
  const size_t n=file.write(snapshot,sizeof(snapshot));file.flush();file.close();
  const bool ok=n==sizeof(snapshot)&&LittleFS.rename("/xuna_bench/snapshot.tmp","/xuna_bench/snapshot.bin");
  if(writes<10000)samples[writes++]=micros()-start;
  if(!ok){Serial.println("ERROR snapshot storm");break;}++sequence;
  if(sequence%20==0)Serial.printf("snapshot_storm_seq=%u\n",sequence);
  if(Serial.available()&&Serial.read()=='q')break;
 }
 report("snapshot_storm",heap);
}

void cleanup(){
 Preferences prefs;bool ok=prefs.begin("xuna_bench",false);
 if(ok){ok=prefs.clear();prefs.end();}Serial.printf("cleanup_bench_nvs_ok=%u\n",ok);
 if(!mounted)return;
 for(unsigned i=0;i<16;++i){char path[48];snprintf(path,sizeof(path),"/xuna_bench/seg%u",i);if(LittleFS.exists(path)&&!LittleFS.remove(path))Serial.printf("ERROR remove %s\n",path);}
 for(const char* path:{"/xuna_bench/snapshot.bin","/xuna_bench/snapshot.tmp","/xuna_bench/recovery.tmp"})
  if(LittleFS.exists(path)&&!LittleFS.remove(path))Serial.printf("ERROR remove %s\n",path);
 if(LittleFS.exists("/xuna_bench")&&!LittleFS.rmdir("/xuna_bench"))Serial.println("ERROR rmdir (retained unknown files)");
}

}
void setup(){
 Serial.begin(115200);displayReady=display.begin();animation.begin(millis());
 Serial.println("S11 isolated harness: A=NVS 1000; B=FS bench (mount only, never autoformat); P=NVS write storm; q=stop storm");
 Serial.println("F=format only fully erased partition; R=recover FS; S=FS append storm; T=snapshot rename storm. q=stop. C=cleanup bench artifacts. No automatic writes.");
}
void loop(){tick();if(!Serial.available())return;const char command=Serial.read();
 if(command=='A')nvsBench(false);else if(command=='B')fsBench();else if(command=='P')nvsBench(true);else if(command=='F')formatErased();else if(command=='R')recoverFs();else if(command=='S')fsStorm();else if(command=='T')snapshotStorm();else if(command=='C')cleanup();
}
