# S11 isolated storage benchmark — preparation

Source baseline: committed firmware be58099 display/animation/config, not the uncommitted refactor. This is an external experiment project, not merged into firmware. Pinned platform/driver and partition layout retained. Build is not hardware validation.

Serial commands (115200): A NVS 1000 A/B 1536-byte writes; B mount-only filesystem append/16KiB rename benchmark; F format only when entire spiffs partition reads erased; P NVS storm; R filesystem recovery; S append storm; T rename snapshot storm; q stop storm; C remove benchmark namespace/files. Nothing writes automatically after boot. Do not send commands before backup/experiment authorization.

Raw samples reside in RAM; logs report sorted p50/p99/max, min/free heap, NVS free entries, filesystem usage and render/tick-gap samples. Tick gaps are benchmark loop gaps, not normal firmware BLE/life loop behavior. Static sample buffers consume 120 KB and distort available heap relative to MVP; report allocation before comparison. No BLE coexistence is tested. Under storms, timing sample buffers cap at 10,000; logs/Serial may affect timings. No wear counter claims.

Execution gates: actual connected board; refreshed verified NVS + full-image backup (filesystem contents included); actual partition table comparison; S01 completion OR explicit owner exception for temporary isolated benchmark. Never erase_flash. Never format a non-erased filesystem. Record physical LCD observation, raw logs and every power cut. Separate 25 cuts per NVS/append/rename mode; report detected torn writes, not presumed mid-write cuts. Snapshot rename interruption does not necessarily expose a torn payload; report observed intact old/new result.

Before power cuts: preserve the initial backup and verify restored MVP behavior after experiment. Missing/corrupt snapshots or failed storage operations stop the experiment; do not reset pet data. The restoration project at ../s11-mvp-restore is a byte-for-byte source copy of committed be58099. Reflash that version after cleanup, without partition changes, then compare actual pet state to baseline; full acceptance still pending S01.

No current hardware measurements. Formatting/recovery/atomicity/namespace isolation remain unvalidated on hardware. D2 must await evidence and owner decision.
